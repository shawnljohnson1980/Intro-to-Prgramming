
function doThis() {
    // Set Height and Age 
    var height = document.querySelector("#height").value;
    var age = document.querySelector("#age").value;
    // Log Age and Height
    console.log (age);
    console.log (height);
    // Set style => Display to None
    document.querySelector("#successHeight").style.display="none";
    document.querySelector("#errorAge").style.display="none";
    document.querySelector("#successAge").style.display="none";
    document.querySelector("#errorHeight").style.display="none";
    // Logic to check age and height
    if (height >= 42) {
        document.querySelector("#successHeight").innerText  = "Meets Height Requirement";
        document.querySelector("#successHeight").style.display="block";
    }
    else {
        document.querySelector("#errorHeight").innerText = "Does not Meet Height Requirements.";
        document.querySelector("#errorHeight").style.display="block";
    }
    if (age >= 10) {
    
        document.querySelector("#successAge").innerText =  "Meets Age Requirements";
        document.querySelector("#successAge").style.display="block";
    ;
    }
    else  {
        document.querySelector("#errorAge").innerText = "Does not Meet Age Requirements";
        document.querySelector("#errorAge").style.display="block";
    }
    
}
