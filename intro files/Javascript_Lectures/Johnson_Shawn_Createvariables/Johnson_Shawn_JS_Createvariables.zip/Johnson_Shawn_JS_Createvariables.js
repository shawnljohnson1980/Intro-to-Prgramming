var height = 45;
var age = 9;
if (height >= 42) console.log("meets height requirement");
else console.log("Does not meet Height requirements.");
if (age >= 10) console.log("Meets Age requirements");
else console.log("Does not meet Age Requirements");