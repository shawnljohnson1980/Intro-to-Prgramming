function greetSomeone(person) {
    person = firstName, salutation
    var firstName = ""

}

var time = new Date().getHours(); {
    var salutation

    if (time > 5, time < 12); {
        salutation = ("Good Morning, ");
    }
    if (time > 12, time <= 19) {
        salutation = ("Good afternoon, ");
    }
    if (time > 19, time < 23) {
        salutation = ("Good evening, ");
    }
    if (time > 23, time < 4) {
        salutation = ("Beautiful night, isn't it?");
    }
}
firstName = "Anakin"
if (firstName == "Anakin") {
    console.log(salutation, firstName);
}

else if (firstName == "Count") {

    console.log("I'm coming for you Dooku!");
}

firstName = "Anakin";
