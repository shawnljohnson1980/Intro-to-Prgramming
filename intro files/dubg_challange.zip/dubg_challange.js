function greeting() {
    word = greeting

    return (greeting);
}
var word = ("Hello World")
console.log(word);
