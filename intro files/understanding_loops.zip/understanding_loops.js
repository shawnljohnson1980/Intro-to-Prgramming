// We need variables for the distance and candy that is to be dropped
//the runner will run a total of 6 miles, var=runner var=miles, var= candy.
//var logdistance/ miles;
//var miles;
//add in a funtion to dispense the candy at 2 miles. and ending at 6 miles. 
//or we use a for loop!
//Adding in an additonal step of logging variables of 2 that dispense candy to give a message to help motivate the runner to continue. 
var miles
for (miles = 0; miles <= 6; miles++); {
}

if (miles == 2) {
    console.log("You've completed 2 miles. Nice work! Keep going.");
}
if (4) {
    console.log("Youve completed 4 miles. Keep it up You're in the home stretch.");
}
if (6) {
    console.log("Congratulations You've completed your run");
}
else (miles > 6)
console.log("You are a superstar keep it up!");
function dispenseCandy() {
}
if (miles % 2) dispenseCandy; {

}
var speed
var candy
for (speed = 0; speed > 5.4; dispenseCandy()); {
    dispenseCandy(candy = 1)
    if (speed > 5.4) {
        console.log("You're Really Cooking!");
    }
}
